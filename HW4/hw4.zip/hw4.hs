module Main where
{-
Name    :
UIN     :
email   :
-} 


-- Q1 -- CSV file. Grade claculations.
main :: IO ()
main = undefined


-- Q2 : matrix Multiplication

data Matrix a = Matrix [[a]]

-- define instance of (*) for matrices. 


-- Q3 tree traversals
data Tree a b = Leaf a | Branch b (Tree a b) (Tree a b)

-- This is a generalized version of expression tree from last week.

preorder :: (a -> c) -> (b -> c) -> Tree a b -> [c]
preorder = undefined 

inorder :: (a -> c) -> (b -> c) -> Tree a b -> [c] 
inorder = undefined

postorder :: (a -> c) -> (b -> c) -> Tree a b -> [c]
postorder = undefined

